package com.xrpl4j.xrpl4j_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Xrpl4jDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
