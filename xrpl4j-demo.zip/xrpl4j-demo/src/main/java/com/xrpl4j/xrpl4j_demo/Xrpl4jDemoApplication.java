package com.xrpl4j.xrpl4j_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Xrpl4jDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Xrpl4jDemoApplication.class, args);
	}

}
